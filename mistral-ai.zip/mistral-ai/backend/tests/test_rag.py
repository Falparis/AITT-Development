from app.services.embeddings import retrieve_context

def test_retrieve_context():
    query = "Qu'est-ce que Mistral AI ?"
    context = retrieve_context(query)
    assert isinstance(context, str)