def clean_text(text):
    return text.strip().replace("\n", " ")