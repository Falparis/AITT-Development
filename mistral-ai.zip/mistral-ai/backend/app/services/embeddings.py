from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings

embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
faiss_index = FAISS.load_local("vector_db", embedding_model)

def retrieve_context(query, k=3):
    results = faiss_index.similarity_search(query, k=k)
    return " ".join([doc.page_content for doc in results])