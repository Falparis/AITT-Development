import os

class Config:
    MODEL_PATH = os.getenv("MODEL_PATH", "./models/mistral-finetuned")
    VECTOR_DB_PATH = os.getenv("VECTOR_DB_PATH", "./vector_db")