# Mistral AI API

Ce projet implémente une API FastAPI utilisant le modèle Mistral 7B avec RAG (Retrieval-Augmented Generation).